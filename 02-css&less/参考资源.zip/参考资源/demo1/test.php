<?php
echo "this is php script";